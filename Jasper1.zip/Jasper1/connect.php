<?php
$Password = $_POST("password");
$email = $_POST("username");


$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "jasper";

$conn = new mysqli($hostname, $username, $password, $dbname );
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $username = $_POST['username'];
    $Password = $_POST['password'];

    // Prepare and execute the query
    $stmt = $conn->prepare("SELECT * FROM users WHERE ('$email', '$Password')
                        VALUE(?,?)");
    $stmt->bind_param("ss", $Email, $Password);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Verify the password using password_verify
        if (password_verify($Password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: home1.php"); // Redirect to home
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "User  not found.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}